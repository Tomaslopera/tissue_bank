"""
auth.py — módulo compartido de autenticación (Lambda Layer).

Dos responsabilidades separadas:
  1. Hashing de contraseñas (bcrypt) — nunca se guarda ni se compara texto
     plano contra la BD.
  2. Emitir y validar JWT — el token que el frontend manda en el header
     `Authorization: Bearer <token>` en cada llamada subsiguiente.

Variable de entorno requerida:
    JWT_SECRET   clave secreta para firmar los tokens (mínimo 32 caracteres
                 aleatorios; se genera una vez y se guarda en Secrets Manager
                 o como variable de entorno de la Lambda — nunca en el código).

Si more adelante se quiere validar el JWT directamente en API Gateway (en
vez de en cada Lambda), esta misma función `decode_token` es la que se
usaría dentro de un Lambda Authorizer.
"""

import os
import time
import bcrypt
import jwt  # PyJWT

TOKEN_TTL_SECONDS = 60 * 60 * 8  # 8 horas


def hash_password(plain_password):
    return bcrypt.hashpw(plain_password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(plain_password, password_hash):
    try:
        return bcrypt.checkpw(plain_password.encode("utf-8"), password_hash.encode("utf-8"))
    except (ValueError, AttributeError):
        # password_hash mal formado o vacío — nunca debe reventar el login,
        # simplemente se trata como credencial inválida.
        return False


def issue_token(user_id, username, role):
    now = int(time.time())
    payload = {
        "sub": user_id,
        "username": username,
        "role": role,
        "iat": now,
        "exp": now + TOKEN_TTL_SECONDS,
    }
    secret = os.environ["JWT_SECRET"]
    return jwt.encode(payload, secret, algorithm="HS256")


class TokenError(Exception):
    pass


def decode_token(token):
    """Devuelve el payload si el token es válido. Lanza TokenError si expiró
    o fue manipulado — quien llama decide qué respuesta HTTP dar."""
    secret = os.environ["JWT_SECRET"]
    try:
        return jwt.decode(token, secret, algorithms=["HS256"])
    except jwt.ExpiredSignatureError:
        raise TokenError("El token expiró, vuelve a iniciar sesión.")
    except jwt.InvalidTokenError:
        raise TokenError("Token inválido.")


def get_auth_context(event):
    """Extrae y valida el JWT del header Authorization de un evento de API
    Gateway. Devuelve el payload decodificado, o None si no hay token
    (el caller decide si eso es aceptable, ej. login no requiere token)."""
    headers = event.get("headers") or {}
    # los headers pueden llegar en cualquier capitalización según el proxy
    auth_header = headers.get("Authorization") or headers.get("authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        return None
    token = auth_header[len("Bearer "):]
    return decode_token(token)


def require_role(payload, *allowed_roles):
    """Valida que el usuario autenticado tenga uno de los roles permitidos.
    Devuelve True/False — quien llama decide si responde 401 o 403."""
    return payload is not None and payload.get("role") in allowed_roles
