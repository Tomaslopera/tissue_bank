"""
db.py — módulo compartido de conexión a Supabase/Postgres.

Este archivo vive en la Lambda Layer (python/db.py) para que las 10 Lambdas
no repitan la misma lógica de conexión. Lee la configuración de variables
de entorno de la Lambda — NUNCA hardcodear credenciales en el código.

Variables de entorno esperadas (se configuran en AWS Lambda > Configuration
> Environment variables, o en la plantilla de SAM/Terraform si se despliega
con infraestructura como código):

    DB_HOST      db.xxxxxxxxxxxx.supabase.co
    DB_PORT      5432   (opcional, default 5432)
    DB_NAME      postgres
    DB_USER      postgres
    DB_PASSWORD  ********

Nota sobre conexiones y Lambda: cada invocación fría (cold start) crea una
conexión nueva; Lambda reutiliza el mismo contenedor entre invocaciones
"calientes" mientras no se reinicie, así que la conexión se cachea a nivel
de módulo (_connection) para no reconectar en cada invocación. Para tráfico
alto en producción, esto igual puede agotar el límite de conexiones de
Postgres si hay muchas Lambdas concurrentes — en ese punto conviene poner
Supabase Connection Pooler (pgbouncer, puerto 6543) en vez del puerto directo
5432, cambiando solo DB_PORT/DB_HOST sin tocar el resto del código.
"""

import os
import psycopg2
import psycopg2.extras

_connection = None


def get_connection():
    """Devuelve una conexión reutilizable a Postgres. Si la conexión se
    cayó (Supabase puede cerrarla por inactividad), se reconecta sola."""
    global _connection

    if _connection is not None:
        try:
            # ping barato para saber si la conexión sigue viva
            cur = _connection.cursor()
            cur.execute("SELECT 1")
            cur.close()
            return _connection
        except Exception:
            try:
                _connection.close()
            except Exception:
                pass
            _connection = None

    _connection = psycopg2.connect(
        host=os.environ["DB_HOST"],
        port=os.environ.get("DB_PORT", "5432"),
        dbname=os.environ.get("DB_NAME", "postgres"),
        user=os.environ.get("DB_USER", "postgres"),
        password=os.environ["DB_PASSWORD"],
        connect_timeout=5,
        sslmode="require",  # Supabase exige SSL
    )
    _connection.autocommit = True
    return _connection


def query(sql, params=None, fetch=True):
    """Ejecuta una consulta y devuelve filas como dicts (o None si fetch=False,
    útil para INSERT/UPDATE que no necesitan devolver filas)."""
    conn = get_connection()
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute(sql, params or ())
        if fetch:
            return [dict(row) for row in cur.fetchall()]
        return None


def query_one(sql, params=None):
    """Igual que query(), pero devuelve solo la primera fila (o None)."""
    rows = query(sql, params)
    return rows[0] if rows else None


class transaction:
    """Context manager para operaciones que escriben en más de una tabla y
    deben tener todo-o-nada (ej. crear doctor = insertar en app_user Y
    doctor_profile; si el segundo insert falla, el primero debe revertirse).

    Uso:
        with transaction() as cur:
            cur.execute("INSERT INTO app_user ...")
            cur.execute("INSERT INTO doctor_profile ...")
        # al salir del bloque sin excepción, se hace COMMIT automático.
        # si algo lanza una excepción dentro del bloque, se hace ROLLBACK.

    Internamente apaga autocommit solo durante el bloque, y lo vuelve a
    encender al salir — así el resto del código (query/query_one) sigue
    funcionando en modo autocommit normal, sin tener que pensar en
    transacciones para los casos de una sola tabla.
    """

    def __enter__(self):
        self.conn = get_connection()
        self.conn.autocommit = False
        self.cur = self.conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        return self.cur

    def __exit__(self, exc_type, exc_val, exc_tb):
        try:
            if exc_type is None:
                self.conn.commit()
            else:
                self.conn.rollback()
        finally:
            self.cur.close()
            self.conn.autocommit = True
        return False  # no suprimir la excepción — que la Lambda la capture y responda 500/400
