"""
response.py — helpers compartidos para todas las Lambdas: formato de
respuesta HTTP consistente con API Gateway (proxy integration), manejo de
errores, y validación básica de campos.
"""

import json
import decimal
import datetime


class JSONEncoderExtra(json.JSONEncoder):
    """Postgres devuelve Decimal para NUMERIC y date/datetime para columnas
    de fecha — json.dumps no sabe serializar esos tipos por defecto."""

    def default(self, obj):
        if isinstance(obj, decimal.Decimal):
            return float(obj)
        if isinstance(obj, (datetime.date, datetime.datetime)):
            return obj.isoformat()
        return super().default(obj)


CORS_HEADERS = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type,Authorization",
    "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
}


def ok(body, status_code=200):
    return {
        "statusCode": status_code,
        "headers": CORS_HEADERS,
        "body": json.dumps(body, cls=JSONEncoderExtra, ensure_ascii=False),
    }


def created(body):
    return ok(body, status_code=201)


def error(message, status_code=400, code="VALIDATION_ERROR", fields=None):
    payload = {"error": {"code": code, "message": message}}
    if fields:
        payload["error"]["fields"] = fields
    return {
        "statusCode": status_code,
        "headers": CORS_HEADERS,
        "body": json.dumps(payload, ensure_ascii=False),
    }


def not_found(entity="Registro"):
    return error(f"{entity} no encontrado.", status_code=404, code="NOT_FOUND")


def unauthorized(message="Debes iniciar sesión para hacer esto."):
    return error(message, status_code=401, code="UNAUTHORIZED")


def forbidden(message="No tienes permiso para hacer esto."):
    return error(message, status_code=403, code="FORBIDDEN")


def server_error(exc):
    # En producción: loguear `exc` a CloudWatch (ya queda en los logs de
    # Lambda automáticamente por el print), pero nunca devolver el detalle
    # crudo de la excepción al cliente — evita filtrar detalles internos.
    print(f"ERROR interno: {exc}")
    return error(
        "Ocurrió un error interno. Intenta de nuevo más tarde.",
        status_code=500,
        code="INTERNAL_ERROR",
    )


def require_fields(body, required):
    """Valida que todos los campos requeridos estén presentes y no vacíos.
    Devuelve un dict {campo: mensaje} con los que faltan, vacío si todo ok."""
    missing = {}
    for field in required:
        value = body.get(field)
        if value is None or (isinstance(value, str) and not value.strip()):
            missing[field] = "Este campo es obligatorio"
    return missing


def parse_body(event):
    """API Gateway (proxy integration) manda el body como string JSON."""
    raw = event.get("body") or "{}"
    if isinstance(raw, (dict, list)):
        return raw
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return {}


def path_param(event, name):
    return (event.get("pathParameters") or {}).get(name)


def query_param(event, name, default=None):
    return (event.get("queryStringParameters") or {}).get(name, default)


def http_method(event):
    """API Gateway tiene dos formatos de evento distintos según el tipo de
    API que se configure:
      - REST API (v1):  event['httpMethod']
      - HTTP API (v2):  event['requestContext']['http']['method']
    Este helper funciona con cualquiera de los dos, para no atarse a una
    decisión de infraestructura que se tome después."""
    if "httpMethod" in event:
        return event["httpMethod"]
    return event.get("requestContext", {}).get("http", {}).get("method", "GET")

